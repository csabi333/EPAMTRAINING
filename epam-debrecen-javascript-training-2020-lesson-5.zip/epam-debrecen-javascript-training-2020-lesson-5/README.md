# EPAM Debrecen JavaScript Training - 2020

If you have any question feel free to send me an email to:
tamas_farago1@epam.com

The homework is on the 33th slide.
