var cl = new Circle(10);

logger.log(cl);
logger.log(cl.area);
logger.log(cl.circumference); 

first.run();
second.run();
third.run();
fourth.run();