# EPAM Debrecen JavaScript Training - 2020

https://community-z.com/events/js-training-2020